from setuptools import setup

setup(
    name="Marvel",
    version="0.0.1",
    description="Marvel Comics",
    author="Marcos de Jesus Fuenmayor Soto",
    author_email="marcos.fuenmayorhtc@gmail.com",
    packages=["testServer", "MarvelComics"],
    install_requires=["flask"],
)
